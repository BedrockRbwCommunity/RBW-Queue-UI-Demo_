# RBW Queue UI Demo — JSON UI Portfolio Project

**Author:** Zack  
**Type:** Minecraft Bedrock Resource Pack / JSON UI prototype  
**Purpose:** A small Ranked Bedwars-inspired HUD panel for a developer portfolio.

## What this demonstrates
- Resource-pack manifest structure
- JSON UI namespace and control definitions
- A custom HUD panel using labels, anchors, offsets, sizing, and layering
- A small, themed UI concept for 3v3 / 4v4 Ranked Bedwars

## Important limitation
This is a **static visual prototype**. The queue and READY labels are demo text; they do not connect to a server, detect a real queue, or create teams. JSON UI alone does not implement backend queue logic.

## Install / test
1. Back up your existing resource packs before testing UI overrides.
2. Import `RBW_Queue_UI_Demo.mcpack` into Minecraft Bedrock by opening the file with Minecraft.
3. Enable the pack in a test world's Resource Packs settings.
4. Enter the world and inspect the HUD.
5. If the HUD does not appear, your Minecraft version may handle UI overrides differently; JSON UI is version-sensitive and can conflict with other UI packs.

## Files
- `manifest.json` — resource pack metadata
- `_ui_defs.json` — registers the UI files
- `ui/rbw_ui.json` — defines the custom RBW panel
- `ui/hud_screen.json` — adds the panel to the HUD

## Portfolio note
Before presenting this as a finished, tested add-on, test it on the exact Bedrock version the server uses. You can describe it honestly as a **JSON UI prototype**, not a completed queue system.
